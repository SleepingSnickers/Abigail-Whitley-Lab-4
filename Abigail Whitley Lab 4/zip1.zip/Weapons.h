#pragma once

#include "Randomizer.h"

#include <iostream>
#include <string>

using namespace std;

class Weapons : public Randomizer
{
protected:
	string name;

public:
	Weapons();
	Weapons(string, int, int);
	~Weapons();

	string getName() const;
	int getWeaponDamage();
	
	virtual string use() = 0;
};

